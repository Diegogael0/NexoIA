from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any

from openai import OpenAI

from .config import settings
from .models import Company


def _compact_context(context: dict[str, Any]) -> dict[str, Any]:
    """Keep only the business data the agent needs; never mix companies."""
    allowed = {"services", "staff", "clients", "appointments", "config"}
    return {k: context.get(k, []) for k in allowed if k in context}


def _instructions(company: Company, context: dict[str, Any]) -> str:
    cfg = context.get("config") or {}
    agent_name = cfg.get("agentName") or company.agent_name or "Nexo"
    greeting = cfg.get("greeting") or company.agent_greeting
    tone = cfg.get("tone") or "Amable y profesional"
    today = date.today().isoformat()
    return f"""
Eres {agent_name}, recepcionista virtual de {company.name}.
Giro del negocio: {company.business_type}.
Fecha actual: {today}.
Tono: {tone}.
Saludo configurado: {greeting}

REGLAS OBLIGATORIAS:
- Atiende exclusivamente a {company.name}; nunca inventes ni mezcles datos de otras empresas.
- Usa únicamente servicios, personal, clientes, horarios y citas incluidos en el contexto recibido.
- Si no conoces un dato, dilo y pregunta lo mínimo necesario.
- No prometas horarios ocupados ni inventes precios.
- Para crear una cita, confirma servicio, profesional, fecha y hora antes de llamar a create_appointment.
- Si falta el nombre del cliente, pregúntalo antes de crear la cita.
- Si el usuario pide un precio y el servicio está en contexto, informa el precio registrado.
- Contesta en español, breve y natural, como recepción real.
- Las acciones de reprogramar/cancelar todavía no están habilitadas en esta versión; explica que un operador puede ayudar si las solicitan.
""".strip()


def _tools() -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "name": "create_appointment",
            "description": "Solicita crear una cita en Nexo IA después de confirmar todos los datos con el cliente.",
            "strict": True,
            "parameters": {
                "type": "object",
                "properties": {
                    "client_name": {"type": "string"},
                    "client_phone": {"type": ["string", "null"]},
                    "service_id": {"type": "integer"},
                    "staff_id": {"type": "integer"},
                    "date": {"type": "string", "description": "Fecha YYYY-MM-DD"},
                    "time": {"type": "string", "description": "Hora HH:MM en 24 horas"},
                },
                "required": ["client_name", "client_phone", "service_id", "staff_id", "date", "time"],
                "additionalProperties": False,
            },
        }
    ]


def _validate_booking(args: dict[str, Any], context: dict[str, Any]) -> tuple[bool, str, dict[str, Any] | None]:
    services = context.get("services") or []
    staff = context.get("staff") or []
    appointments = context.get("appointments") or []

    service = next((s for s in services if int(s.get("id", -1)) == int(args["service_id"])), None)
    professional = next((s for s in staff if int(s.get("id", -1)) == int(args["staff_id"])), None)
    if not service or not professional:
        return False, "El servicio o profesional no existe en esta empresa.", None

    try:
        datetime.strptime(args["date"], "%Y-%m-%d")
        datetime.strptime(args["time"], "%H:%M")
    except ValueError:
        return False, "La fecha u hora no tiene un formato válido.", None

    # The frontend performs the detailed schedule/buffer validation as a second guard.
    conflict = next(
        (
            a
            for a in appointments
            if int(a.get("staffId", -1)) == int(args["staff_id"])
            and a.get("date") == args["date"]
            and str(a.get("time", ""))[:5] == args["time"][:5]
            and a.get("status") != "Cancelada"
        ),
        None,
    )
    if conflict:
        return False, "Ese profesional ya tiene una cita que inicia exactamente a esa hora.", None

    action = {
        "type": "create_appointment",
        "client_name": args["client_name"].strip(),
        "client_phone": (args.get("client_phone") or "").strip(),
        "service_id": int(args["service_id"]),
        "staff_id": int(args["staff_id"]),
        "date": args["date"],
        "time": args["time"][:5],
        "origin": "Chat IA",
    }
    return True, "La solicitud de cita quedó lista para registrarse en Nexo IA.", action


def chat_with_agent(company: Company, message: str, history: list[dict[str, str]], context: dict[str, Any]) -> dict[str, Any]:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY no está configurada en el servidor")

    client = OpenAI(api_key=settings.openai_api_key)
    safe_context = _compact_context(context)
    conversation: list[dict[str, Any]] = []
    for item in history[-12:]:
        role = item.get("role")
        content = str(item.get("content") or "").strip()
        if role in {"user", "assistant"} and content:
            conversation.append({"role": role, "content": content})

    context_text = json.dumps(safe_context, ensure_ascii=False, default=str)
    user_input = conversation + [
        {
            "role": "user",
            "content": f"CONTEXTO ACTUAL DE LA EMPRESA (datos internos):\n{context_text}\n\nMENSAJE DEL CLIENTE:\n{message.strip()}",
        }
    ]

    response = client.responses.create(
        model=settings.openai_model,
        instructions=_instructions(company, safe_context),
        input=user_input,
        tools=_tools(),
        max_output_tokens=700,
    )

    actions: list[dict[str, Any]] = []
    tool_outputs: list[dict[str, Any]] = []
    for item in response.output:
        if getattr(item, "type", None) != "function_call":
            continue
        if item.name == "create_appointment":
            try:
                args = json.loads(item.arguments)
                ok, result, action = _validate_booking(args, safe_context)
                if ok and action:
                    actions.append(action)
                payload = {"ok": ok, "message": result}
            except Exception as exc:
                payload = {"ok": False, "message": f"No fue posible validar la cita: {exc}"}
            tool_outputs.append(
                {"type": "function_call_output", "call_id": item.call_id, "output": json.dumps(payload, ensure_ascii=False)}
            )

    if tool_outputs:
        response = client.responses.create(
            model=settings.openai_model,
            instructions=_instructions(company, safe_context),
            previous_response_id=response.id,
            input=tool_outputs,
            max_output_tokens=500,
        )

    return {"reply": response.output_text.strip(), "actions": actions}
