from datetime import datetime, timedelta
import json
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import or_
from .config import settings
from .db import Base, engine, get_db, SessionLocal
from .models import User, Company, Membership, Branch, Staff, Service, Client, Appointment
from .schemas import LoginIn, TokenOut, CompanyCreate, CompanyOut, AdminUserCreate, AdminUserUpdate, AdminProfileUpdate, BranchCreate, StaffCreate, ServiceCreate, ClientCreate, AppointmentCreate, AgentChatIn, AgentChatOut
from .auth import hash_password, verify_password, create_token, current_user, require_company_access, require_platform_admin
from .agent import chat_with_agent

Base.metadata.create_all(bind=engine)

def bootstrap_admin():
    db = SessionLocal()
    try:
        # If an administrator already exists, preserve any username/password changes.
        user = db.query(User).filter(User.is_platform_admin==True).order_by(User.id).first()
        if not user:
            user = db.query(User).filter(
                or_(User.username==settings.admin_username, User.email==settings.admin_email)
            ).first()
        if not user:
            user = User(
                username=settings.admin_username,
                email=settings.admin_email,
                name="Administrador Nexo IA",
                password_hash=hash_password(settings.admin_password),
                is_platform_admin=True,
                is_active=True,
            )
            db.add(user)
            db.commit()
        else:
            user.is_platform_admin = True
            user.is_active = True
            db.commit()
    finally:
        db.close()

bootstrap_admin()

app = FastAPI(title="Nexo IA API", version="0.5.0")
origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True, "service": "nexo-api", "version":"0.5.0", "agent_ready": bool(settings.openai_api_key)}

@app.post("/auth/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    key=body.login.strip().lower()
    user=db.query(User).filter(or_(User.username==key, User.email==key)).first()
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Usuario o contraseña incorrectos")
    return {"access_token": create_token(user.id)}

@app.get("/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    memberships=db.query(Membership).filter(Membership.user_id==user.id).all()
    companies=[]
    for mem in memberships:
        c=db.get(Company, mem.company_id)
        if c:
            companies.append({
                "id":c.id,"name":c.name,"plan":c.plan,"business_type":c.business_type,
                "role":mem.role,"permissions":json.loads(mem.permissions or "[]")
            })
    return {
        "id":user.id,"name":user.name,"username":user.username,"email":user.email,
        "is_platform_admin":user.is_platform_admin,"companies":companies
    }


@app.put("/admin/profile")
def update_admin_profile(body: AdminProfileUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    require_platform_admin(user)
    username = body.username.strip().lower()
    email = str(body.email).strip().lower()

    existing_username = db.query(User).filter(User.username==username, User.id!=user.id).first()
    if existing_username:
        raise HTTPException(409, "Ese nombre de usuario ya está ocupado")

    existing_email = db.query(User).filter(User.email==email, User.id!=user.id).first()
    if existing_email:
        raise HTTPException(409, "Ese correo ya está registrado")

    user.name = body.name.strip()
    user.username = username
    user.email = email
    if body.new_password:
        user.password_hash = hash_password(body.new_password)

    db.commit()
    return {"ok": True, "username": user.username, "email": user.email, "name": user.name}

@app.post("/companies", response_model=CompanyOut)
def create_company(body: CompanyCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    require_platform_admin(user)
    company=Company(**body.model_dump())
    db.add(company); db.flush()
    db.add(Branch(company_id=company.id,name="Principal"))
    db.commit(); db.refresh(company)
    return company

@app.get("/companies", response_model=list[CompanyOut])
def list_companies(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.is_platform_admin:
        return db.query(Company).order_by(Company.name).all()
    return db.query(Company).join(Membership,Membership.company_id==Company.id).filter(Membership.user_id==user.id).all()

@app.get("/admin/users")
def admin_users(user: User = Depends(current_user), db: Session = Depends(get_db)):
    require_platform_admin(user)
    rows=[]
    memberships=db.query(Membership).all()
    for mem in memberships:
        u=db.get(User,mem.user_id); c=db.get(Company,mem.company_id)
        if u and c:
            rows.append({
                "id":u.id,"name":u.name,"username":u.username,"email":u.email,
                "is_active":u.is_active,"company_id":c.id,"company_name":c.name,
                "role":mem.role,"permissions":json.loads(mem.permissions or "[]")
            })
    return rows

@app.post("/admin/users")
def create_company_user(body: AdminUserCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    require_platform_admin(user)
    company=db.get(Company,body.company_id)
    if not company: raise HTTPException(404,"Empresa no encontrada")
    username=body.username.strip().lower()
    email=str(body.email).strip().lower()
    if db.query(User).filter(or_(User.username==username,User.email==email)).first():
        raise HTTPException(409,"El usuario o correo ya existe")
    u=User(username=username,email=email,name=body.name,password_hash=hash_password(body.password),is_active=True)
    db.add(u);db.flush()
    db.add(Membership(user_id=u.id,company_id=company.id,role=body.role,permissions=json.dumps(body.permissions)))
    db.commit();db.refresh(u)
    return {"ok":True,"id":u.id,"username":u.username,"company_id":company.id}

@app.put("/admin/users/{user_id}")
def update_company_user(user_id:int, body:AdminUserUpdate, user:User=Depends(current_user), db:Session=Depends(get_db)):
    require_platform_admin(user)
    u=db.get(User,user_id)
    if not u or u.is_platform_admin: raise HTTPException(404,"Usuario no encontrado")
    mem=db.query(Membership).filter(Membership.user_id==u.id).first()
    if not mem: raise HTTPException(404,"Asignación de empresa no encontrada")

    if body.username is not None:
        username=body.username.strip().lower()
        exists=db.query(User).filter(User.username==username,User.id!=u.id).first()
        if exists: raise HTTPException(409,"Ese nombre de usuario ya está ocupado")
        u.username=username

    if body.email is not None:
        email=str(body.email).strip().lower()
        exists=db.query(User).filter(User.email==email,User.id!=u.id).first()
        if exists: raise HTTPException(409,"Ese correo ya está registrado")
        u.email=email

    if body.company_id is not None:
        company=db.get(Company,body.company_id)
        if not company: raise HTTPException(404,"Empresa no encontrada")
        mem.company_id=company.id

    if body.name is not None: u.name=body.name.strip()
    if body.password: u.password_hash=hash_password(body.password)
    if body.role is not None: mem.role=body.role
    if body.permissions is not None: mem.permissions=json.dumps(body.permissions)
    if body.is_active is not None: u.is_active=body.is_active
    db.commit()
    return {"ok":True,"id":u.id}

def scope(company_id:int,user:User,db:Session):
    require_company_access(company_id,user,db)

@app.post("/companies/{company_id}/branches")
def create_branch(company_id:int,body:BranchCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    obj=Branch(company_id=company_id,**body.model_dump());db.add(obj);db.commit();db.refresh(obj);return obj

@app.get("/companies/{company_id}/staff")
def list_staff(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);return db.query(Staff).filter(Staff.company_id==company_id,Staff.is_active==True).all()

@app.post("/companies/{company_id}/staff")
def create_staff(company_id:int,body:StaffCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);obj=Staff(company_id=company_id,**body.model_dump());db.add(obj);db.commit();db.refresh(obj);return obj

@app.get("/companies/{company_id}/services")
def list_services(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);return db.query(Service).filter(Service.company_id==company_id,Service.is_active==True).all()

@app.post("/companies/{company_id}/services")
def create_service(company_id:int,body:ServiceCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);obj=Service(company_id=company_id,**body.model_dump());db.add(obj);db.commit();db.refresh(obj);return obj

@app.get("/companies/{company_id}/clients")
def list_clients(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);return db.query(Client).filter(Client.company_id==company_id).order_by(Client.name).all()

@app.post("/companies/{company_id}/clients")
def create_client(company_id:int,body:ClientCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);obj=Client(company_id=company_id,**body.model_dump());db.add(obj);db.commit();db.refresh(obj);return obj

@app.get("/companies/{company_id}/appointments")
def list_appointments(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db);return db.query(Appointment).filter(Appointment.company_id==company_id).order_by(Appointment.appointment_date,Appointment.start_time).all()

@app.post("/companies/{company_id}/appointments")
def create_appointment(company_id:int,body:AppointmentCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    service=db.query(Service).filter(Service.id==body.service_id,Service.company_id==company_id).first()
    staff=db.query(Staff).filter(Staff.id==body.staff_id,Staff.company_id==company_id).first()
    client=db.query(Client).filter(Client.id==body.client_id,Client.company_id==company_id).first()
    branch=db.query(Branch).filter(Branch.id==body.branch_id,Branch.company_id==company_id).first()
    if not all([service,staff,client,branch]): raise HTTPException(400,"Algún recurso no pertenece a la empresa")
    start_dt=datetime.combine(body.appointment_date,body.start_time)
    end_time=(start_dt+timedelta(minutes=service.duration_minutes+service.buffer_minutes)).time()
    conflict=db.query(Appointment).filter(
        Appointment.company_id==company_id,Appointment.staff_id==body.staff_id,
        Appointment.appointment_date==body.appointment_date,Appointment.status.notin_(["Cancelada"]),
        Appointment.start_time<end_time,Appointment.end_time>body.start_time
    ).first()
    if conflict: raise HTTPException(409,"El profesional ya tiene una cita en ese horario")
    obj=Appointment(company_id=company_id,end_time=end_time,**body.model_dump())
    db.add(obj);db.commit();db.refresh(obj);return obj


@app.post("/companies/{company_id}/agent/chat", response_model=AgentChatOut)
def agent_chat(company_id:int, body:AgentChatIn, user:User=Depends(current_user), db:Session=Depends(get_db)):
    scope(company_id,user,db)
    company=db.get(Company,company_id)
    if not company:
        raise HTTPException(404,"Empresa no encontrada")
    try:
        return chat_with_agent(company, body.message, [x.model_dump() for x in body.history], body.context)
    except RuntimeError as exc:
        raise HTTPException(503,str(exc))
    except Exception as exc:
        raise HTTPException(502,f"No fue posible obtener respuesta del agente: {exc}")

# ---------------------------------------------------------------------------
# Conversaciones reales: bandeja de entrada, chat web público y toma humana.
# ---------------------------------------------------------------------------
from sqlalchemy import desc
from .models import Conversation, ConversationMessage
from .schemas import PublicChatIn, OperatorMessageIn


def _serialize_message(m):
    return {"id":m.id,"sender":m.sender,"content":m.content,"created_at":m.created_at.isoformat()}


def _serialize_conversation(db, c, include_messages=False):
    last=db.query(ConversationMessage).filter(ConversationMessage.conversation_id==c.id).order_by(desc(ConversationMessage.id)).first()
    out={
        "id":c.id,"company_id":c.company_id,"channel":c.channel,"contact_name":c.contact_name or "Cliente nuevo",
        "contact_phone":c.contact_phone or "","mode":c.mode,"status":c.status,"intent":c.intent,"ai_state":c.ai_state,
        "updated_at":c.updated_at.isoformat(),"last_message":last.content if last else "",
        "last_sender":last.sender if last else ""
    }
    if include_messages:
        msgs=db.query(ConversationMessage).filter(ConversationMessage.conversation_id==c.id).order_by(ConversationMessage.id).all()
        out["messages"]=[_serialize_message(x) for x in msgs]
    return out


def _db_agent_context(db, company_id:int):
    # Preferred source while the operational modules are being migrated: a PostgreSQL-backed
    # company state snapshot with the exact frontend data structure.
    try:
        state_row=db.get(CompanyState,company_id)
        if state_row and state_row.payload:
            snapshot=json.loads(state_row.payload)
            if snapshot.get("services") or snapshot.get("staff") or snapshot.get("clients") or snapshot.get("appointments"):
                return {k:snapshot.get(k, [] if k!="config" else {}) for k in ["services","staff","clients","appointments","config"]}
    except Exception:
        pass
    services=db.query(Service).filter(Service.company_id==company_id,Service.is_active==True).all()
    staff=db.query(Staff).filter(Staff.company_id==company_id,Staff.is_active==True).all()
    clients=db.query(Client).filter(Client.company_id==company_id).all()
    apps=db.query(Appointment).filter(Appointment.company_id==company_id).all()
    return {
        "services":[{"id":x.id,"name":x.name,"price":float(x.price or 0),"duration":x.duration_minutes} for x in services],
        "staff":[{"id":x.id,"name":x.name,"short":x.alias or x.name.split()[0],"role":x.role,"present":x.present,"status":x.operational_status} for x in staff],
        "clients":[{"id":x.id,"name":x.name,"phone":x.phone,"notes":x.notes or ""} for x in clients],
        "appointments":[{"id":x.id,"date":x.appointment_date.isoformat(),"time":x.start_time.strftime("%H:%M"),"clientId":x.client_id,"serviceId":x.service_id,"staffId":x.staff_id,"status":x.status,"origin":x.origin} for x in apps],
        "config":{}
    }


def _execute_agent_actions(db, company_id:int, actions:list[dict]):
    results=[]
    state_row=db.get(CompanyState,company_id)
    snapshot=None
    if state_row and state_row.payload:
        try: snapshot=json.loads(state_row.payload)
        except Exception: snapshot=None
    if snapshot is not None:
        services=snapshot.get("services") or []; staff=snapshot.get("staff") or []; clients=snapshot.get("clients") or []; appointments=snapshot.get("appointments") or []
        for a in actions:
            if a.get("type")!="create_appointment": continue
            service=next((x for x in services if int(x.get("id",-1))==int(a.get("service_id",-2))),None)
            professional=next((x for x in staff if int(x.get("id",-1))==int(a.get("staff_id",-2))),None)
            if not service or not professional:
                results.append({"ok":False,"message":"Servicio o profesional no encontrado."}); continue
            digits=lambda v: ''.join(ch for ch in str(v or '') if ch.isdigit())
            phone=a.get("client_phone") or ''
            client=next((x for x in clients if digits(x.get("phone")) and digits(x.get("phone"))==digits(phone)),None)
            if not client:
                new_id=max([int(x.get("id",0)) for x in clients] or [0])+1
                client={"id":new_id,"name":a.get("client_name") or "Cliente","phone":phone,"notes":"Registrado por agente IA","favoriteStaff":None};clients.append(client)
            conflict=next((x for x in appointments if int(x.get("staffId",-1))==int(a.get("staff_id")) and x.get("date")==a.get("date") and str(x.get("time",''))[:5]==str(a.get("time",''))[:5] and x.get("status")!="Cancelada"),None)
            if conflict:
                results.append({"ok":False,"message":"El horario dejó de estar disponible."}); continue
            new_id=max([int(x.get("id",0)) for x in appointments] or [0])+1
            appointments.append({"id":new_id,"date":a.get("date"),"time":str(a.get("time"))[:5],"clientId":client["id"],"serviceId":int(a.get("service_id")),"staffId":int(a.get("staff_id")),"status":"Confirmada","origin":"Chat web IA"})
            results.append({"ok":True,"appointment_id":new_id})
        snapshot["clients"]=clients;snapshot["appointments"]=appointments
        state_row.payload=json.dumps(snapshot,ensure_ascii=False,default=str);state_row.updated_at=datetime.utcnow()
        return results
    for a in actions:
        if a.get("type") != "create_appointment":
            continue
        service=db.query(Service).filter(Service.id==int(a["service_id"]),Service.company_id==company_id).first()
        staff=db.query(Staff).filter(Staff.id==int(a["staff_id"]),Staff.company_id==company_id).first()
        branch=db.query(Branch).filter(Branch.company_id==company_id,Branch.is_active==True).order_by(Branch.id).first()
        if not all([service,staff,branch]):
            results.append({"ok":False,"message":"Faltan sucursal, servicio o profesional configurados en el servidor."}); continue
        phone=(a.get("client_phone") or "").strip() or "sin-telefono"
        client=db.query(Client).filter(Client.company_id==company_id,Client.phone==phone).first()
        if not client:
            client=Client(company_id=company_id,name=a.get("client_name") or "Cliente",phone=phone,notes="Registrado por agente IA")
            db.add(client); db.flush()
        ap_date=datetime.strptime(a["date"],"%Y-%m-%d").date(); start=datetime.strptime(a["time"],"%H:%M").time()
        start_dt=datetime.combine(ap_date,start); end=(start_dt+timedelta(minutes=service.duration_minutes+service.buffer_minutes)).time()
        conflict=db.query(Appointment).filter(Appointment.company_id==company_id,Appointment.staff_id==staff.id,Appointment.appointment_date==ap_date,Appointment.status!="Cancelada",Appointment.start_time<end,Appointment.end_time>start).first()
        if conflict:
            results.append({"ok":False,"message":"El horario dejó de estar disponible."}); continue
        ap=Appointment(company_id=company_id,branch_id=branch.id,client_id=client.id,staff_id=staff.id,service_id=service.id,appointment_date=ap_date,start_time=start,end_time=end,status="Confirmada",origin="Chat web IA")
        db.add(ap); db.flush(); results.append({"ok":True,"appointment_id":ap.id})
    return results

@app.get("/companies/{company_id}/conversations")
def list_conversations(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    rows=db.query(Conversation).filter(Conversation.company_id==company_id,Conversation.status!="deleted").order_by(desc(Conversation.updated_at)).all()
    return [_serialize_conversation(db,x) for x in rows]

@app.get("/companies/{company_id}/conversations/{conversation_id}")
def get_conversation(company_id:int,conversation_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    c=db.query(Conversation).filter(Conversation.id==conversation_id,Conversation.company_id==company_id).first()
    if not c: raise HTTPException(404,"Conversación no encontrada")
    return _serialize_conversation(db,c,True)

@app.post("/companies/{company_id}/conversations/{conversation_id}/take")
def take_conversation(company_id:int,conversation_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db); c=db.query(Conversation).filter(Conversation.id==conversation_id,Conversation.company_id==company_id).first()
    if not c: raise HTTPException(404,"Conversación no encontrada")
    c.mode="operator"; c.updated_at=datetime.utcnow(); db.commit(); return {"ok":True,"mode":"operator"}

@app.post("/companies/{company_id}/conversations/{conversation_id}/return-ai")
def return_conversation_ai(company_id:int,conversation_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db); c=db.query(Conversation).filter(Conversation.id==conversation_id,Conversation.company_id==company_id).first()
    if not c: raise HTTPException(404,"Conversación no encontrada")
    c.mode="ai"; c.updated_at=datetime.utcnow(); db.commit(); return {"ok":True,"mode":"ai"}

@app.post("/companies/{company_id}/conversations/{conversation_id}/messages")
def operator_message(company_id:int,conversation_id:int,body:OperatorMessageIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db); c=db.query(Conversation).filter(Conversation.id==conversation_id,Conversation.company_id==company_id).first()
    if not c: raise HTTPException(404,"Conversación no encontrada")
    if c.mode!="operator": raise HTTPException(409,"Primero debes tomar la conversación")
    m=ConversationMessage(conversation_id=c.id,sender="operator",content=body.message.strip()); db.add(m); c.updated_at=datetime.utcnow(); db.commit(); db.refresh(m)
    return _serialize_message(m)

@app.get("/public/companies/{company_id}")
def public_company(company_id:int,db:Session=Depends(get_db)):
    c=db.query(Company).filter(Company.id==company_id).first()
    if not c: raise HTTPException(404,"Empresa no encontrada")
    return {"id":c.id,"name":c.name,"business_type":c.business_type,"agent_name":c.agent_name,"greeting":c.agent_greeting,"primary_color":c.primary_color}

@app.get("/public/companies/{company_id}/chat/{session_key}")
def public_chat_history(company_id:int,session_key:str,db:Session=Depends(get_db)):
    c=db.query(Conversation).filter(Conversation.company_id==company_id,Conversation.channel=="web",Conversation.external_id==session_key).first()
    if not c: return {"conversation_id":None,"mode":"ai","messages":[]}
    return _serialize_conversation(db,c,True)

@app.post("/public/companies/{company_id}/chat")
def public_chat(company_id:int,body:PublicChatIn,db:Session=Depends(get_db)):
    company=db.query(Company).filter(Company.id==company_id).first()
    if not company: raise HTTPException(404,"Empresa no encontrada")
    c=db.query(Conversation).filter(Conversation.company_id==company_id,Conversation.channel=="web",Conversation.external_id==body.session_key).first()
    if not c:
        c=Conversation(company_id=company_id,channel="web",external_id=body.session_key,contact_name=body.name or "Cliente web",contact_phone=body.phone,mode="ai",status="open")
        db.add(c); db.flush()
    else:
        if body.name: c.contact_name=body.name
        if body.phone: c.contact_phone=body.phone
    incoming=ConversationMessage(conversation_id=c.id,sender="client",content=body.message.strip()); db.add(incoming); c.updated_at=datetime.utcnow(); db.flush()
    reply=None; actions=[]
    if c.mode=="ai":
        history_rows=db.query(ConversationMessage).filter(ConversationMessage.conversation_id==c.id,ConversationMessage.id!=incoming.id).order_by(ConversationMessage.id).all()
        history=[]
        for m in history_rows[-12:]:
            role="assistant" if m.sender in {"assistant","operator"} else "user"
            history.append({"role":role,"content":m.content})
        try:
            result=chat_with_agent(company,body.message,history,_db_agent_context(db,company_id))
            reply=result.get("reply") or "¿En qué más puedo ayudarte?"; actions=result.get("actions") or []
            _execute_agent_actions(db,company_id,actions)
            db.add(ConversationMessage(conversation_id=c.id,sender="assistant",content=reply))
        except Exception as exc:
            reply="En este momento un operador continuará contigo."
            c.mode="operator"; c.ai_state="IA no disponible"
            db.add(ConversationMessage(conversation_id=c.id,sender="assistant",content=reply))
    db.commit(); db.refresh(c)
    return {"conversation_id":c.id,"mode":c.mode,"reply":reply,"actions":actions}

from .models import CompanyState
from .schemas import CompanyStateIn

@app.get("/companies/{company_id}/state")
def get_company_state(company_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    row=db.get(CompanyState,company_id)
    if not row: return {"payload":{}}
    try: return {"payload":json.loads(row.payload or "{}")}
    except Exception: return {"payload":{}}

@app.put("/companies/{company_id}/state")
def put_company_state(company_id:int,body:CompanyStateIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    scope(company_id,user,db)
    row=db.get(CompanyState,company_id)
    if not row:
        row=CompanyState(company_id=company_id,payload=json.dumps(body.payload,ensure_ascii=False,default=str));db.add(row)
    else:
        row.payload=json.dumps(body.payload,ensure_ascii=False,default=str);row.updated_at=datetime.utcnow()
    db.commit(); return {"ok":True,"updated_at":row.updated_at.isoformat()}
